﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace USSRTourAgency
{
    /// <summary>
    /// Логика взаимодействия для HotelPage.xaml
    /// </summary>
    public partial class HotelPage : Page
    {
        private List<Hotel> candidates; // Список всех абитуриентов
        private List<Hotel> filteredCandidates; // Отфильтрованный список абитуриентов после поиска
        private int currentPage = 1; // Текущая страница
        private int itemsPerPage = 4; // Количество записей на странице

        public HotelPage()
        {
            InitializeComponent();
            LoadCandidates(); // Загружаем список абитуриентов
            LoadPage(); // Загружаем первую страницу
        }
        private void LoadCandidates()
        {
            // Загрузка всех абитуриентов из базы данных
            candidates = TourAgencyEntities.GetContext().Hotels.ToList();
        }

        private void LoadPage()
        {
            // Вычисляем общее количество страниц и максимальную страницу
            var totalCount = filteredCandidates != null ? filteredCandidates.Count : candidates.Count;
            var maxPage = (int)Math.Ceiling((double)totalCount / itemsPerPage);

            // Получаем текущую страницу
            var currentPageCandidates = filteredCandidates != null
                ? filteredCandidates.Skip((currentPage - 1) * itemsPerPage).Take(itemsPerPage).ToList()
                : candidates.Skip((currentPage - 1) * itemsPerPage).Take(itemsPerPage).ToList();

            // Заполняем список абитуриентов на текущей странице
            Abit.ItemsSource = currentPageCandidates;

            // Обновляем номер текущей страницы и текст на кнопках
            CurrentPageTextBlock.Text = currentPage.ToString();
        }

        private void SortComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Получаем выбранный вариант сортировки из комбобокса
            var selectedSortOption = SortComboBox.SelectedItem as ComboBoxItem;

            if (selectedSortOption != null)
            {
                var sortOption = selectedSortOption.Content.ToString();

                // Сортируем список абитуриентов в соответствии с выбранной сортировкой
                switch (sortOption)
                {
                    case "По фамилии":
                        candidates = candidates.OrderBy(c => c.HotelName).ToList();
                        break;

                    case "По специальности":
                        candidates = candidates.OrderBy(c => c.HotelID).ToList();
                        break;

                    default:
                        break;
                }

                // Если был выполнен поиск, снова применяем фильтр к отсортированным данным
                if (filteredCandidates != null)
                {
                    filteredCandidates = filteredCandidates.OrderBy(c => c.HotelName).ToList();
                }

                // Возвращаемся на первую страницу после сортировки
                currentPage = 1;
                LoadPage();
            }
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string searchTerm = searchBox.Text.ToLower();
            filteredCandidates = TourAgencyEntities.GetContext().Hotels
                .Where(c => c.HotelName.ToLower().Contains(searchTerm))
                .ToList();

            currentPage = 1;
            LoadPage();
        }

        private void PreviousPageButton_Click(object sender, RoutedEventArgs e)
        {
            if (currentPage > 1)
            {
                currentPage--;
                LoadPage();
            }
        }

        private void NextPageButton_Click(object sender, RoutedEventArgs e)
        {
            var totalCount = filteredCandidates != null ? filteredCandidates.Count : candidates.Count;
            var maxPage = (int)Math.Ceiling((double)totalCount / itemsPerPage);

            if (currentPage < maxPage)
            {
                currentPage++;
                LoadPage();
            }
        }

        private void Back_Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Menu());
        }
    }
}
