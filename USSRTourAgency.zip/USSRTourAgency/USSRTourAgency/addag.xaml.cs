﻿using USSRTourAgency;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace USSRTourAgency
{
    /// <summary>
    /// Логика взаимодействия для addag.xaml
    /// </summary>
    public partial class addag : Page
    {
        private Client _currentUs = new Client();
        public addag(Client abit)
        {
            InitializeComponent();
            LoadAndInitData(abit);
        }
        void LoadAndInitData(Client abit)
        {
            if (abit != null)
            {
                _currentUs = abit;
            }
            DataContext = _currentUs;
        }
        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (_currentUs.ClientID == 0)
            {

                TourAgencyEntities.GetContext().Clients.Add(_currentUs);

            }
            try
            {
                TourAgencyEntities.GetContext().SaveChanges();
                MessageBox.Show("Запись Изменена");
                NavigationService.Navigate(new ratetable());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            NavigationService.GoBack();
        }


    }
}
