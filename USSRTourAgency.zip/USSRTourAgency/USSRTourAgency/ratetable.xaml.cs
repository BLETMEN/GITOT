﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using USSRTourAgency.Converters;

namespace USSRTourAgency
{
    /// <summary>
    /// Логика взаимодействия для ratetable.xaml
    /// </summary>
    public partial class ratetable : Page
    {
        public ratetable()
        {
            InitializeComponent();
            InitializeButtonsVisibility();
            // Загружаем список кандидатов в DataGrid
            LoadCandidates();
        }
        private void LoadAbiturients()
        {
            var abiturients = TourAgencyEntities.GetContext().Clients.ToList();
            ratetab.ItemsSource = abiturients;
        }

        private void LoadCandidates()
        {
            // Получаем список кандидатов из базы данных
            List<Client> candidates = TourAgencyEntities.GetContext().Clients.ToList();

            int userRole = AuthStorage.Role;

            // Устанавливаем видимость кнопки "Редактировать" для каждого кандидата
            foreach (var candidate in candidates)
            {
                candidate.IsEditButtonVisible = userRole == 1 || userRole == 2;
            }

            // Устанавливаем источник данных для DataGrid
            ratetab.ItemsSource = candidates;
            if (userRole != 2 && userRole != 1)
            {
                DataGridTemplateColumn editColumn = ratetab.Columns.FirstOrDefault(column => column.Header.ToString() == "Редактировать") as DataGridTemplateColumn;
                if (editColumn != null)
                {
                    editColumn.Visibility = Visibility.Collapsed;
                }
            }

        }
        private void InitializeButtonsVisibility()
        {
            int userRole = AuthStorage.Role;
            Add.Visibility = userRole == 2 || userRole == 1 ? Visibility.Visible : Visibility.Collapsed;
            Del.Visibility = userRole == 2 || userRole == 1 ? Visibility.Visible : Visibility.Collapsed;

        }
        private void add_Click(object sender, RoutedEventArgs e)
        {


            NavigationService.Navigate(new addag(null));




        }
        private void del_Click(object sender, RoutedEventArgs e)
        {
            var selectedAbiturients = ratetab.SelectedItems.Cast<Client>().ToList();
            MessageBoxResult messageBoxResult = MessageBox.Show($"Удалить {selectedAbiturients.Count()} записей?", "Удаление", MessageBoxButton.OKCancel, MessageBoxImage.Question);

            if (messageBoxResult == MessageBoxResult.OK)
            {
                try
                {
                    var context = TourAgencyEntities.GetContext();

                    foreach (var abiturient in selectedAbiturients)
                    {
                        // Удаляем связанные записи в CandidateExams
                        var relatedExams = context.Bookings.Where(ce => ce.ClientID == abiturient.ClientID).ToList();
                        context.Bookings.RemoveRange(relatedExams);

                        // Теперь удаляем запись абитуриента
                        context.Clients.Remove(abiturient);
                    }


                    context.SaveChanges();

                    MessageBox.Show("Записи удалены");

                    List<Client> candidates = context.Clients.OrderBy(p => p.LastName).ToList();
                    ratetab.ItemsSource = null;
                    ratetab.ItemsSource = candidates;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка удаления", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }


        private void back(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Menu());
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            // Получаем выбранного кандидата из DataContext кнопки
            if (sender is Button btn && btn.DataContext is Client candidate && candidate.IsEditButtonVisible)
            {
                // Переходим на страницу редактирования кандидата
                NavigationService.Navigate(new addag(candidate));

                // Обновляем DataGrid после редактирования
                LoadCandidates();
            }
        }

    }
}