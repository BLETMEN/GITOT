﻿using System;
using System.Windows.Controls;

namespace Aktivnocti.Models
{
    internal class Manager
    {
        public static Frame MainFrame { get; set; }
        public static User CurrentUser { get; set; }
    }
}
