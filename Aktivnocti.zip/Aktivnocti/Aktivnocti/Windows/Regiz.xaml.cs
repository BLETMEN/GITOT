﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Aktivnocti.Models;
namespace Aktivnocti.Windows
{
    /// <summary>
    /// Логика взаимодействия для Regiz.xaml
    /// </summary>
    public partial class Regiz : Window
    {
        private User _currentUser = new User();
        private string _filePath = null;
        private string _photoName = null;
        private bool _photoChanged = false;
        private static string _currentDirectory = Directory.GetCurrentDirectory() + @"\Images\Izd\";

        public Regiz(User selectedUser)
        {
            InitializeComponent();
            LoadAndInitData(selectedUser);
        }
        void LoadAndInitData(User selectedUser)
        {
            if (selectedUser != null)
            {
                _currentUser = selectedUser;
            }
            // контекст данных текущий товар
            DataContext = _currentUser;
            CmbPol.ItemsSource = KonkursEntities.GetContext().Pols.ToList();

            CmbNapravlenie.ItemsSource = KonkursEntities.GetContext().Napravlenies.ToList();

            CmbMeropriytie.ItemsSource = KonkursEntities.GetContext().Napravlenies.ToList();

            CmbRol.ItemsSource = KonkursEntities.GetContext().Rols.ToList();
        }
        private StringBuilder CheckFields()
        {
            StringBuilder s = new StringBuilder();
            // проверка полей на содержимое
            if (string.IsNullOrWhiteSpace(_currentUser.Name))
                s.AppendLine("Поле имя пустое");
            if (string.IsNullOrWhiteSpace(_currentUser.Familia))
                s.AppendLine("Поле Фамилия пустое");
            if (string.IsNullOrWhiteSpace(_currentUser.Otchestvo))
                s.AppendLine("Поле отчество пустое");
            if (_currentUser.Pol == null)
               s.AppendLine("Выберите свой пол");
            if (_currentUser.Rol == null)
                s.AppendLine("Выберите свою роль");
            if (_currentUser.Napravlenie == null)
                s.AppendLine("Выберите направление");
            if (string.IsNullOrWhiteSpace(_currentUser.Number))
                s.AppendLine("Поле телефон пустое");
            if (string.IsNullOrWhiteSpace(_currentUser.Mail))
                s.AppendLine("Поле почта пустое");
            return s;
        }

        private void BtnZagruz_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Microsoft.Win32.OpenFileDialog op = new Microsoft.Win32.OpenFileDialog();
                op.Title = "Select a picture";
                op.Filter = "JPEG Files (*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|JPG Files (*.jpg) | *.jpg | GIF Files(*.gif) | *.gif";
                if (op.ShowDialog() == true)
                {
                    FileInfo fileInfo = new FileInfo(op.FileName);
                    if (fileInfo.Length > (1024 * 1024 * 2))
                    {
                        throw new Exception("Размер файла должен быть меньше 2Мб");
                    }
                    Img.Source = new BitmapImage(new Uri(op.FileName));
                    _photoName = op.SafeFileName;
                    _filePath = op.FileName;
                    _photoChanged = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                _filePath = null;
            }

        }
        string ChangePhotoName()
        {
            string x = _currentDirectory + _photoName;
            string photoname = _photoName;
            int i = 0;
            if (File.Exists(x))
            {
                while (File.Exists(x))
                {
                    i++;
                    x = _currentDirectory + i.ToString() + photoname;
                }
                photoname = i.ToString() + photoname;
            }
            return photoname;
        }
    }
}
